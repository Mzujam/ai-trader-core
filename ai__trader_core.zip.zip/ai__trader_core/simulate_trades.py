import yaml
from data_loader import load_historical_data
from strategy_ai import StrategyAI
from rebalance_engine import SmartRebalancer

with open("config.yaml", "r") as file:
    config = yaml.safe_load(file)

portfolio = {a["name"]: a["strategy"] for a in config["assets"]}
data = {
    asset: load_historical_data(
        asset,
        config["simulation"]["date_range"]["start"],
        config["simulation"]["date_range"]["end"]
    )
    for asset in portfolio
}

market_state = "range"

# Dummy strategy result simulation
class DummyStrategy:
    def __init__(self, name):
        self.name = name
    def run(self, data): return self
    def get_roi(self): return 10.0
    def get_win_rate(self): return 70
    def get_confidence(self): return 85

strategy_scores = {}
for asset, strategy in portfolio.items():
    ai = StrategyAI(data[asset], [DummyStrategy(strategy)], market_state)
    scores = ai.evaluate()
    strategy_scores[strategy] = scores[strategy]

rebalancer = SmartRebalancer(portfolio, strategy_scores, market_state)
new_weights = rebalancer.rebalance()

print("🔁 New portfolio allocation:")
for asset, weight in new_weights.items():
    print(f"{asset}: {weight}")