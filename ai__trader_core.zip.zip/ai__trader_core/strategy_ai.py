class StrategyAI:
    def __init__(self, data, strategies, market_state):
        self.data = data
        self.strategies = strategies
        self.market_state = market_state

    def evaluate(self):
        results = {}
        for strat in self.strategies:
            strat_result = strat.run(self.data)
            results[strat.name] = {
                "roi": strat_result.get_roi(),
                "win_rate": strat_result.get_win_rate(),
                "confidence_score": strat_result.get_confidence(),
                "market_fit": self.assess_market_fit(strat.name)
            }
        return results

    def assess_market_fit(self, strategy_name):
        if strategy_name == "RSI" and self.market_state == "range":
            return "Optimal"
        elif strategy_name == "ML" and self.market_state == "volatile":
            return "Optimal"
        return "Suboptimal"