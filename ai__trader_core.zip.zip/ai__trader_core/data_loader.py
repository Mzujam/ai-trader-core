def load_historical_data(asset, start, end):
    import pandas as pd
    import numpy as np
    dates = pd.date_range(start=start, end=end)
    data = pd.DataFrame(index=dates)
    data["close"] = np.random.uniform(100, 200, size=len(dates))
    return data