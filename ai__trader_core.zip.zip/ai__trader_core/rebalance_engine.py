class SmartRebalancer:
    def __init__(self, portfolio, strategy_scores, market_state):
        self.portfolio = portfolio
        self.strategy_scores = strategy_scores
        self.market_state = market_state

    def rebalance(self):
        new_weights = {}
        total_score = sum([
            s["confidence_score"] * s["roi"]
            for s in self.strategy_scores.values()
        ])

        for asset, strat in self.portfolio.items():
            score = (
                self.strategy_scores[strat]["confidence_score"]
                * self.strategy_scores[strat]["roi"]
            )
            allocation = round(score / total_score, 4)
            new_weights[asset] = allocation

        return new_weights